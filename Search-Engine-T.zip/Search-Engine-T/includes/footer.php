						</div>
                    </div>
                    <!-- end dashboard information/content section -->
                </div>
            </div>
        </section>
        <footer class="footer-section">
            <div class="container-fluid">
                
            </div>
        </footer>        
        <!-- all js link -->
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/all.min.js"></script>
        <!-- bootstrap form validate js -->
        <script src="assets/js/bootstrap-validate.js"></script>
        <script src="assets/js/custom.js"></script>
    </body>
</html>
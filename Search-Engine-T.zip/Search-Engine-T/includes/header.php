<!DOCTYPE html>
<html>
    <head>
        <title> Search-Engine </title>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- add icon link -->
        <link rel = "icon" href ="assets/img/icon_logo.png" type = "image/x-icon">
        <link rel="stylesheet" href="assets/css/all.min.css">
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/style.css">
        <!-- data table css -->
        <link rel="stylesheet" href="assets/css/jquery.dataTables.min.css">
        <script src="assets/js/jquery-3.6.0.min.js"></script>
        <!-- data table js -->
        <script src="assets/js/jquery.dataTables.min.js"></script>
        <!-- sweet alert -->
        <script src="assets/js/sweetalert.min.js"></script>
    </head>
    
    
    
    <body>
    
        <header>
            
        
            <div class="container-fluid header_container">
                <div class="row p-3 mb-3 header_row">
                    
                </div>
            </div>
        
        </header>
        <section class="content-section">
        
            <div class="container-fluid">
                <!-- dashboard -->
                <div class="row">
